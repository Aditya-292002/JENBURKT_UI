import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-setting',
  templateUrl: './company-setting.component.html',
  styleUrls: ['./company-setting.component.css']
})
export class CompanySettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
