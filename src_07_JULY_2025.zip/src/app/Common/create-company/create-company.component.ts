import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-company',
  templateUrl: './create-company.component.html',
  styleUrls: ['./create-company.component.css']
})
export class CreateCompanyComponent implements OnInit {
  COUNTRY = [];
  STATE=[];
  CITY=[];
  constructor() { }

  ngOnInit(): void {
  }
  

}
